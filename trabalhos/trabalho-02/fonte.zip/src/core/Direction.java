package core;

public enum Direction {
	RIGHT,
	LEFT,
	FRONT,
	BACK
}
