package core;

public interface IRobotic {
	void moviment();
	void rotate(Direction direction);
}
