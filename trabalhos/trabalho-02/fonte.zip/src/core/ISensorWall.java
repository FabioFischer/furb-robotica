package core;

public interface ISensorWall {
	boolean detect(Direction direction);
}
